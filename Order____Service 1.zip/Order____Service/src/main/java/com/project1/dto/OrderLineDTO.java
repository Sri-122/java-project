package com.project1.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class OrderLineDTO {
	private Long orderLineId;

    @NotNull(message = "{orderLine.quantity.required}")
    @Min(value = 1, message = "{orderLine.quantity.min}")
    private Integer quantity;

    @NotNull(message = "{orderLine.productId.required}")
    private Long productId;

    // Default constructor
    public OrderLineDTO() {
    }

    // Constructor with parameters
    public OrderLineDTO(Long orderLineId, Integer quantity, Long productId) {
        this.orderLineId = orderLineId;
        this.quantity = quantity;
        this.productId = productId;
    }

    // Getters and Setters
    public Long getOrderLineId() {
        return orderLineId;
    }

    public void setOrderLineId(Long orderLineId) {
        this.orderLineId = orderLineId;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

}
