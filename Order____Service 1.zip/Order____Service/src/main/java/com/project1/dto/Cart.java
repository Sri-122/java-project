package com.project1.dto;

public class Cart {
	private int cartId;
    private Integer productCount;
    private Double total;
    private int userId;
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public Integer getProductCount() {
		return productCount;
	}
	public void setProductCount(Integer productCount) {
		this.productCount = productCount;
	}
	public Double getTotal() {
		return total;
	}
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Cart(int cartId, Integer productCount, Double total, int userId) {
		super();
		this.cartId = cartId;
		this.productCount = productCount;
		this.total = total;
		this.userId = userId;
	}
	public void setTotal(Double total) {
		this.total = total;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}

}
