package com.project1.service;

import java.time.LocalDate;

import java.util.List;

import com.project1.dto.OrderDTO;
import com.project1.entity.Order;
import com.project1.exception.OrderNotFoundException;

public interface IOrderService {

    OrderDTO addOrder(OrderDTO orderDTO);
    OrderDTO updateOrder(Long orderId, OrderDTO orderDTO);
    OrderDTO viewOrder(Long orderId);
	List<OrderDTO> viewOrdersByUserId(int userId);
	List<OrderDTO> viewOrdersByLocation(String location);
	List<OrderDTO> viewOrdersByDate(LocalDate orderDate);
	Order removeOrder(Long id) throws OrderNotFoundException;
	
	
	
}
 