package com.project1.exception;

public class OrderLineNotFoundException extends RuntimeException{
	public OrderLineNotFoundException(String message) {
        super(message);
	}

}
