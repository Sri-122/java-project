package com.sweetmart.repo;

import com.sweetmart.dto.CartDTO;
import com.sweetmart.model.Cart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ICartRepository extends JpaRepository<Cart, Integer> {
    // No need to define findAllById, it's already provided by JpaRepository
}