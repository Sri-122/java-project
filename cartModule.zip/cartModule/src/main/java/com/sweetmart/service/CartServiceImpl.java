package com.sweetmart.service;

import com.sweetmart.client.ProductServiceClient;
import com.sweetmart.dto.CartDTO;
import com.sweetmart.dto.Product;
import com.sweetmart.exceptions.CartNotFoundException;
import com.sweetmart.model.Cart;
import com.sweetmart.repo.ICartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartServiceImpl implements ICartService {

    @Autowired
    private ICartRepository cartRepo;

    @Autowired
    private ProductServiceClient productServiceClient;

    @Override
    public CartDTO addCart(CartDTO cartDTO) {
        Cart cart = convertToEntity(cartDTO);
//        cart.setUserId(cartDTO.getUserId());
//        Cart new_cart = cartRepo.save(cart);
//        cart.setCartId(new_cart.getCartId());
//        cart.setUserId(new_cart.getUserId());
//        cart.setTotal(calculateTotalCost(cart.getProductId(), cart.getProductCount()));
//        Cart cart=convertToEntity(cartDTO);
//        Cart new_cart=cartRepo.save(cart);
//        new_cart.setUserId(cart.getUserId());

        cart.setTotal(calculateTotalCost(cart.getProductId(), cart.getProductCount()));
        cart.setUserId(cartDTO.getUserId());
        Cart savedCart=cartRepo.save(cart);
        savedCart.setCartId(cartDTO.getCartId());
        return convertToDTO(savedCart);

    }

    @Override
    public CartDTO updateCart(CartDTO cartDTO) throws CartNotFoundException {
        int cartId = cartDTO.getCartId();
        Cart oldCart = cartRepo.findById(cartId).orElseThrow(() -> new CartNotFoundException("Cart not found with id: " + cartId));
        Cart updatedCart = convertToEntity(cartDTO);
        updatedCart.setUserId(cartDTO.getUserId());
        cartRepo.save(updatedCart);
        return convertToDTO(updatedCart);
    }
    @Override
    public String cancelCart(Integer cartId) throws CartNotFoundException {
        Cart cart = cartRepo.findById(cartId).orElseThrow(() -> new CartNotFoundException("Cart not found"));
        cartRepo.delete(cart);
        return "Cart deleted successfully";
    }

    @Override
    public List<Cart> showAllCarts() {
        return cartRepo.findAll();
    }


    @Override
    public Cart showCartById(Integer cartId) throws CartNotFoundException {
        Cart cart = cartRepo.findById(cartId).orElseThrow(() -> new CartNotFoundException("Cart not found"));
        return cart;
    }

    public Double calculateTotalCost(List<Integer> productId, int productCount) {
        double totalCost = 0;
        for (Integer id : productId) {
            List<Product> product = productServiceClient.showAllProducts(id);
            totalCost += product.get(0).getPrice() * productCount;
        }
        return totalCost;
    }


    public CartDTO convertToDTO(Cart cart) {
        CartDTO cartDTO = new CartDTO();

        cartDTO.setProductId(cart.getProductId());
        cartDTO.setTotal(cart.getTotal());
        cartDTO.setProductCount(cart.getProductCount());
        cartDTO.setUserId(cart.getUserId());
        return cartDTO;
    }

    public Cart convertToEntity(CartDTO cartDTO) {
        Cart cart = new Cart();
        cart.setCartId(cartDTO.getCartId());

        cart.setProductId(cartDTO.getProductId());
        cart.setProductCount(cartDTO.getProductCount());
        cart.setTotal(cartDTO.getTotal());
        return cart;
    }

}