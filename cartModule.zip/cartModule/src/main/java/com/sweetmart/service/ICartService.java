package com.sweetmart.service;

import com.sweetmart.dto.CartDTO;
import com.sweetmart.exceptions.CartNotFoundException;
import com.sweetmart.model.Cart;

import java.util.List;

public interface ICartService {
    public CartDTO addCart(CartDTO cart);

    public CartDTO updateCart(CartDTO cart) throws CartNotFoundException;

    public String cancelCart(Integer cartId) throws CartNotFoundException;

    public List<Cart> showAllCarts();

    public Cart showCartById(Integer cartId) throws CartNotFoundException;

    public Double calculateTotalCost(List<Integer> productId, int productCount);
}
