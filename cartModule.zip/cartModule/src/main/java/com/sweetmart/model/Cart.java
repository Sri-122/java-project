package com.sweetmart.model;

import java.util.List;
import com.sweetmart.dto.Product;
import jakarta.persistence.*;


@Entity
@Table(name="Cart")
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int cartId;
    private int userId;
    private Integer productCount;
    private Double total;
    private List<Integer> productId;

    public Cart() {
        super();
    }

    public Integer getProductCount() {
        return productCount;
    }

    public void setProductCount(Integer productCount) {
        this.productCount = productCount;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }
    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public List<Integer> getProductId() {
        return productId;
    }

    public void setProductId(List<Integer> productId) {
        this.productId = productId;
    }
    public Cart(int cartId, int userId, Integer productCount, Double total, List<Integer> productId) {
        this.cartId = cartId;
        this.userId = userId;

        this.productCount = productCount;
        this.total = total;
        this.productId = productId;
    }
}