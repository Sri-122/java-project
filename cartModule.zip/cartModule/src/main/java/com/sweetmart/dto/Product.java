package com.sweetmart.dto;

import com.sweetmart.model.Cart;
import jakarta.persistence.*;

public class Product {

    private Integer productId;
    private String name;
    private String photoPath;
    private Double price;
    private String description;
    private Boolean available = true;

    private Cart cart;

    // Getters and Setters

    public Boolean getAvailable() {
        return available;
    }

    public void setAvailable(Boolean available) {
        this.available = available;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhotoPath() {
        return photoPath;
    }

    public void setPhotoPath(String photoPath) {
        this.photoPath = photoPath;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public Product(Integer productId, String name, String photoPath, Double price, String description, Boolean available, Cart cart) {
        this.productId = productId;
        this.name = name;
        this.photoPath = photoPath;
        this.price = price;
        this.description = description;
        this.available = available;
        this.cart = cart;
    }

    public Product() {
    }
}
