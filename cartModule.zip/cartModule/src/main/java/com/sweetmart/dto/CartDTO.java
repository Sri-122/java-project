package com.sweetmart.dto;
import java.util.List;

import jakarta.persistence.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class CartDTO {

    private int cartId;
    private int userId;


    @NotNull(message="{productCount.null}")
    @Positive(message="{productCount.negative}")
    private Integer productCount;

//    @NotNull(message = "{total.null}")
//    @Positive(message="{total.negative}")
    private Double total;

    @NotNull(message = "{productId.null}")
    private List<Integer> productId;

    public CartDTO() {
        super();
    }

    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }



    public Integer getProductCount() {
        return productCount;
    }

    public void setProductCount(Integer productCount) {
        this.productCount = productCount;
    }

    public CartDTO(int cartId, Integer productCount, Double total, List<Integer> productId) {
        this.cartId = cartId;

        this.productCount = productCount;
        this.total = total;
        this.productId = productId;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public List<Integer> getProductId() {
        return productId;
    }

    public void setProductId(List<Integer> productId) {
        this.productId = productId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}
