package com.capgemini.service;

import java.util.List;

import com.capgemini.DTO.ProductDTO;
import com.capgemini.entity.Category;
import com.capgemini.entity.Product;
import com.capgemini.exception.ProductNotFoundException;

public interface IProductService {
	List<Product> viewAllProducts();

    Product addProduct(ProductDTO productDTO);

    Product updateProduct(ProductDTO productDTO) throws ProductNotFoundException;

    Product viewProduct(Long id) throws ProductNotFoundException;

    List<Product> viewProductsByCategory(Category category);

    Product removeProduct(Long id) throws ProductNotFoundException;
}
