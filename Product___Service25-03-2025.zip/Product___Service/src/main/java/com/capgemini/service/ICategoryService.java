package com.capgemini.service;

import java.util.List;

import com.capgemini.DTO.CategoryDTO;
import com.capgemini.entity.Category;
import com.capgemini.exception.CategoryAlreadyExists;
import com.capgemini.exception.CategoryNotFoundException;

public interface ICategoryService {
	List<Category> viewAllCategories();

    Category addCategory(CategoryDTO categoryDTO) throws CategoryAlreadyExists;

    Category updateCategory(CategoryDTO categoryDTO) throws CategoryNotFoundException;

    Category viewCategory(Long id) throws CategoryNotFoundException;
 
    Category getCategoryByName(String name) throws CategoryNotFoundException;
    void removeCategory(Long id) throws CategoryNotFoundException;
}
