package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.DTO.CategoryDTO;
import com.capgemini.entity.Category;
import com.capgemini.exception.CategoryAlreadyExists;
import com.capgemini.exception.CategoryNotFoundException;
import com.capgemini.service.ICategoryService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/category")
public class CategoryController {
	@Autowired
    private ICategoryService categoryService;

    // Get all categories
    @GetMapping("/getAllCategories")
    public ResponseEntity<List<Category>> getAllCategories() {
        // Retrieve all categories from the service
        List<Category> categories = categoryService.viewAllCategories();
        
        // Return the list of Category objects with HTTP status 200 OK
        return new ResponseEntity<>(categories, HttpStatus.OK); // Returns 200 OK with the list of Category entities
    }

    // Get category by ID
    @GetMapping("/getCategoryById/{id}")
    public ResponseEntity<Category> getCategoryById(@PathVariable Long id) throws  CategoryNotFoundException{
            Category category = categoryService.viewCategory(id); // This will throw CategoryNotFoundException if not found
            return new ResponseEntity<>(category,HttpStatus.OK);
    }

    // Add a new category
    @PostMapping("/addCategory")
    public ResponseEntity<Category> addCategory(@Valid @RequestBody CategoryDTO categoryDTO) throws CategoryAlreadyExists{
            // Try to add the category. If category already exists, it will throw CategoryAlreadyExists
            Category category = categoryService.addCategory(categoryDTO);
            
            // Return the created category object as the response (success case)
            return new ResponseEntity<>(category,HttpStatus.CREATED);
    }

    // Update an existing category
    @PutMapping("/updateCategory/{id}")
    public ResponseEntity<Category> updateCategory(@PathVariable Long id, @Valid @RequestBody CategoryDTO categoryDTO) throws CategoryNotFoundException{
            // Set the ID from the path variable to the categoryDTO object
            categoryDTO.setId(id);
            
            // Call the service layer to update the category and get the updated category
            Category updatedCategory = categoryService.updateCategory(categoryDTO);
            
            // Return a success response with the message and the updated category
            return new ResponseEntity<>(updatedCategory,HttpStatus.OK);
       
    }


    // Delete category by ID
    @DeleteMapping("/deleteCategory/{id}")
    public ResponseEntity<String> deleteCategory(@PathVariable Long id) throws CategoryNotFoundException{
            // Check if the category exists
            Category categoryToDelete = categoryService.viewCategory(id); 

            // Proceed with the deletion
            categoryService.removeCategory(id); // This might throw CategoryNotFoundException
            
            // Return a success message along with the deleted category's ID
            return ResponseEntity.status(HttpStatus.OK)
    	            .body("Category with ID " + id + " deleted successfully.");
               
    }

    // Helper method to convert Category to CategoryDTO
    private CategoryDTO convertToCategoryDTO(Category category) {
        return new CategoryDTO(category.getId(), category.getName());
    }
}