package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.DTO.ProductDTO;
import com.capgemini.entity.Category;
import com.capgemini.entity.Product;
import com.capgemini.exception.CategoryNotFoundException;
import com.capgemini.exception.ProductNotFoundException;
import com.capgemini.service.ICategoryService;
import com.capgemini.service.IProductService;

import jakarta.validation.Valid;

@RestController
@Validated
@RequestMapping("/product")
public class ProductController {
	    @Autowired
	    private IProductService productService;
	    
	    @Autowired
	    private ICategoryService categoryService;

	    // Method to get all products
	    @GetMapping("/getAllProducts") 
	    public ResponseEntity<List<Product>> getAllProducts() {
	        List<Product> products = productService.viewAllProducts();
	        return new ResponseEntity<>(products, HttpStatus.OK);
	    }

	    // Method to add a new product
	    @PostMapping("/addProduct")
	    public ResponseEntity<Product> addProduct(@Valid @RequestBody ProductDTO productDTO) {
	        Product addedProduct = productService.addProduct(productDTO);
	        return new ResponseEntity<>(addedProduct, HttpStatus.CREATED);
	    }

	    // Method to update an existing product
	    @PutMapping("/updateProduct/{id}")
	    public ResponseEntity<Product> updateProduct(@PathVariable Long id, @Valid @RequestBody ProductDTO productDTO) throws ProductNotFoundException {
	        // Set the Product ID from the path variable
	        productDTO.setProductId(id);
	        	        
	        Product updatedProduct = productService.updateProduct(productDTO);
	        return new ResponseEntity<>(updatedProduct, HttpStatus.OK);
	    }

	    // Method to get a product by ID
	    @GetMapping("/getProductsById/{id}")
	    public ResponseEntity<Product> getProductById(@PathVariable Long id) throws ProductNotFoundException {
	        Product product = productService.viewProduct(id);
	        return new ResponseEntity<>(product, HttpStatus.OK);
	    }

	    // Method to get products by category
	    @GetMapping("/getCategoryByNmae/{cat}")
	    public ResponseEntity<List<Product>> getProductsByCategory(@PathVariable String cat) throws CategoryNotFoundException {
	        // Fetch Category by name
	        Category category = categoryService.getCategoryByName(cat); // Assuming you have this method in your service

	        // Fetch products by category from productService
	        List<Product> products = productService.viewProductsByCategory(category);
	        
	        return new ResponseEntity<>(products, HttpStatus.OK);
	    }

	    // Method to remove a product
	    @DeleteMapping("/removeProduct/{id}")
	    public ResponseEntity<Object> removeProduct(@PathVariable Long id) throws ProductNotFoundException {
	    	 Product productToDelete = productService.viewProduct(id);  // Assuming viewProduct method retrieves the product by ID

	    	    // Proceed with the removal process
	    	    productService.removeProduct(id); // This might throw ProductNotFoundException

	    	    // Return success message after deletion
	    	    return ResponseEntity.status(HttpStatus.OK)
	    	            .body("Product with ID " + id + " deleted successfully.");
	    }

	    // Helper method to convert ProductDTO to Product
	    private Product convertToProduct(ProductDTO productDTO) {
	        Product product = new Product();
	       product.setProductId(productDTO.getProductId());
	        product.setProductName(productDTO.getProductName());
	        product.setPrice(productDTO.getPrice());
	        product.setQuantity(productDTO.getQuantity());
	        return product;
	    }
}