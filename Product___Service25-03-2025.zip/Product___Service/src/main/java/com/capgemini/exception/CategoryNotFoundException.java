package com.capgemini.exception;


public class CategoryNotFoundException extends Exception {
	public CategoryNotFoundException(String message) {
			super(message);
		}
	public CategoryNotFoundException() {
	}
}