package com.capgemini.DTO;

import com.capgemini.entity.Category;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class ProductDTO {

    private Long productId;

    @NotBlank(message = "{productName.notBlank}")
    @Size(min = 0, max = 100, message = "{productName.size}")
    @Pattern(regexp = "^[A-Za-z\\s]+$", message = "{validation.product.productName.pattern}")
    private String productName;

    @Min(value = 0, message = "{price.min}")
    private double price;

    @Min(value = 0, message = "{quantity.min}")
    private int quantity;

    @NotBlank(message = "{color.notBlank}")
    private String color;

    @NotNull(message = "{category.notNull}")
    private Category category;

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

  
}
