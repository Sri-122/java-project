package com.capgemini;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.capgemini.dto.Userdto;
import com.capgemini.entity.Users;
import com.capgemini.exception.UserNotFoundException;
import com.capgemini.repository.UserRepository;
import com.capgemini.service.UserServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class UserService1ApplicationTests {

	@Mock
	private UserRepository userRepository;

	@InjectMocks
	private UserServiceImpl userService;

	private Userdto userDto;
	private Users user;

	@BeforeEach
	void setUp() {
		userDto = new Userdto();
		userDto.setUserId(1);
		userDto.setUserName("John Doe");
		userDto.setEmail("john@example.com");

		user = new Users();
		user.setUserId(1);
		user.setUserName("John Doe");
		user.setEmail("john@example.com");
	}

	@Test
	void testRegisterUser() {
		when(userRepository.save(any(Users.class))).thenReturn(user);
		Userdto savedUser = userService.registerUser(userDto);
		assertNotNull(savedUser);
		assertEquals(userDto.getUserId(), savedUser.getUserId());
	}

	@Test
	void testGetAllUsers() {
		when(userRepository.findAll()).thenReturn(Arrays.asList(user));
		List<Userdto> users = userService.getAllUsers();
		assertFalse(users.isEmpty());
		assertEquals(1, users.size());
	}

	@Test
	void testGetUserById() {
		when(userRepository.findById(1)).thenReturn(Optional.of(user));
		Optional<Userdto> foundUser = userService.getUserById(1);
		assertTrue(foundUser.isPresent());
		assertEquals(userDto.getUserId(), foundUser.get().getUserId());
	}

	@Test
	void testGetUserByIdNotFound() {
		when(userRepository.findById(1)).thenReturn(Optional.empty());

		Exception exception = assertThrows(UserNotFoundException.class, () ->
				userService.getUserById(1).orElseThrow(() -> new UserNotFoundException("User not found")));

		assertEquals("User not found", exception.getMessage());
	}
}
