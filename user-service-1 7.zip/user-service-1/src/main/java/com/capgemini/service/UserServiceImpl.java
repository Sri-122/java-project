package com.capgemini.service;

import com.capgemini.dto.Userdto;
import com.capgemini.entity.Users;
import com.capgemini.exception.UserNotFoundException;
import com.capgemini.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private UserRepository userRepository;

    @Override
    public Userdto registerUser(Userdto userDto) {
        logger.info("Registering user: {}", userDto.getUserName());
        Users user = convertToEntity(userDto);
        user = userRepository.save(user);
        logger.info("User registered successfully with ID: {}", user.getUserId());
        return convertToDto(user);
    }

    @Override
    public List<Userdto> getAllUsers() {
        logger.info("Fetching all users");
        return userRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<Userdto> getUserById(int userId) {
        logger.info("Fetching user with ID: {}", userId);
        return userRepository.findById(userId)
                .map(this::convertToDto);
    }

    @Override
    public void deleteUserById(int userId) {
        logger.warn("Deleting user with ID: {}", userId);
        userRepository.deleteById(userId);
        logger.info("User with ID {} deleted successfully", userId);
    }

    @Override
    public Userdto updateUser(int userId, Userdto updatedUserDto) {
        logger.info("Updating user with ID: {}", userId);
        Optional<Users> optionalUser = userRepository.findById(userId);
        if (optionalUser.isPresent()) {
            Users user = optionalUser.get();
            user.setFirstName(updatedUserDto.getFirstName());
            user.setLastName(updatedUserDto.getLastName());
            user.setUserName(updatedUserDto.getUserName());
            user.setEmail(updatedUserDto.getEmail());
            user.setPassword(updatedUserDto.getPassword());
            user.setRoles(updatedUserDto.getRoles());
            user = userRepository.save(user);
            logger.info("User with ID {} updated successfully", userId);
            return convertToDto(user);
        } else {
            logger.error("User not found with ID: {}", userId);
            throw new UserNotFoundException("User not found with ID: " + userId);
        }
    }

    @Override
    public Optional<Userdto> login(String userName, String password) {
        logger.info("Attempting login for user: {}", userName);
        Optional<Users> optionalUser = userRepository.findByUserNameAndPassword(userName, password);
        if (optionalUser.isPresent()) {
            logger.info("Login successful for user: {}", userName);
        } else {
            logger.warn("Login failed for user: {}", userName);
        }
        return optionalUser.map(this::convertToDto);
    }

    @Override
    public Optional<Userdto> findByUserName(String userName) {
        logger.info("Fetching user by username: {}", userName);
        return userRepository.findByUserName(userName)
                .map(this::convertToDto);
    }

    private Userdto convertToDto(Users user) {
        Userdto userDto = new Userdto();
        userDto.setUserId(user.getUserId());
        userDto.setFirstName(user.getFirstName());
        userDto.setLastName(user.getLastName());
        userDto.setUserName(user.getUserName());
        userDto.setEmail(user.getEmail());
        userDto.setPassword(user.getPassword());
        userDto.setRoles(user.getRoles());
        return userDto;
    }

    private Users convertToEntity(Userdto userDto) {
        Users user = new Users();
        user.setUserId(userDto.getUserId());
        user.setFirstName(userDto.getFirstName());
        user.setLastName(userDto.getLastName());
        user.setUserName(userDto.getUserName());
        user.setEmail(userDto.getEmail());
        user.setPassword(userDto.getPassword());
        user.setRoles(userDto.getRoles());
        return user;
    }
}
