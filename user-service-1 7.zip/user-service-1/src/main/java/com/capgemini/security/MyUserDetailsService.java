package com.capgemini.security;


import com.capgemini.entity.Users;
import com.capgemini.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.stream.Collectors;
 

 
@Component
@Service
public class MyUserDetailsService implements UserDetailsService {
 
    @Autowired
    private UserRepository userRepository;
 
    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
 
        Optional<Users> opt=userRepository.findByUserName(userName);
        if(opt.isEmpty()){
            throw new UsernameNotFoundException("User Not Found");
        }
        Users user=opt.get();
        org.springframework.security.core.userdetails.User u=new
                org.springframework.security.core.userdetails.User(user.getUserName(),user.getPassword(),
                user.getRoles().stream().map( r->new SimpleGrantedAuthority(r.toString())).collect(Collectors.toSet()));
        return u;
    }
}