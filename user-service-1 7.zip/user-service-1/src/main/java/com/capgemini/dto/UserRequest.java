package com.capgemini.dto;

public class UserRequest {
    private String userName;
 
    public String getUserName() {
        return userName;
    }
 
    public void setUsername(String userName) {
        this.userName = userName;
    }
 
    public String getPassword() {
        return password;
    }
 
    public void setPassword(String password) {
        this.password = password;
    }
 
    private String password;
}
