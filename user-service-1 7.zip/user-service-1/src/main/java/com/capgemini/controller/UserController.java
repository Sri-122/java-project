package com.capgemini.controller;


import com.capgemini.dto.UserRequest;
import com.capgemini.dto.UserResponse;
import com.capgemini.dto.Userdto;
import com.capgemini.exception.UserNotFoundException;
import com.capgemini.jwt.JwtUtil;
import com.capgemini.service.UserService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value="/users")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @Autowired
    private JwtUtil jwtService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping(value="/register")
    public ResponseEntity<Userdto> registerUser(@Valid @RequestBody Userdto userdto) {
        logger.info("Registering user: {}", userdto.getUserName());
        userdto.setPassword(passwordEncoder.encode(userdto.getPassword()));
        Userdto createdUser = userService.registerUser(userdto);
        logger.info("User registered successfully: {}", createdUser.getUserName());
        return new ResponseEntity<>(createdUser, HttpStatus.CREATED);
    }

    @PostMapping(value = "/login")
    public ResponseEntity<UserResponse> login(@RequestBody UserRequest userRequest) {
        logger.info("Attempting login for user: {}", userRequest.getUserName());
        try {
            UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
                    userRequest.getUserName(), userRequest.getPassword()
            );
            var authentication = authenticationManager.authenticate(authenticationToken);
            if (authentication.isAuthenticated()) {
                var token = jwtService.generateToken(userRequest.getUserName());
                logger.info("Login successful for user: {}", userRequest.getUserName());
                return new ResponseEntity<>(new UserResponse("Login Success", token), HttpStatus.OK);
            } else {
                logger.warn("Login failed for user: {}", userRequest.getUserName());
                return new ResponseEntity<>(new UserResponse("Login Failed", null), HttpStatus.UNAUTHORIZED);
            }
        } catch (BadCredentialsException ex) {
            logger.error("Invalid credentials for user: {}", userRequest.getUserName());
            return new ResponseEntity<>(new UserResponse("Invalid username or password", null), HttpStatus.UNAUTHORIZED);
        } catch (Exception ex) {
            logger.error("Unexpected error during login for user: {}: {}", userRequest.getUserName(), ex.getMessage());
            return new ResponseEntity<>(new UserResponse("An unexpected error occurred: " + ex.getMessage(), null), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/allusers")
    public ResponseEntity<List<Userdto>> getAllUsers() {
        logger.info("Fetching all users");
        List<Userdto> users = userService.getAllUsers();
        return new ResponseEntity<>(users, HttpStatus.OK);
    }

    @GetMapping("/userbyid/{id}")
    public ResponseEntity<Userdto> getUserById(@PathVariable int id) {
        logger.info("Fetching user by ID: {}", id);
        Optional<Userdto> userDto = userService.getUserById(id);
        return userDto.map(user -> new ResponseEntity<>(user, HttpStatus.OK))
                .orElseThrow(() -> {
                    logger.warn("User not found with ID: {}", id);
                    return new UserNotFoundException("User not found with ID: " + id);
                });
    }

    @DeleteMapping("remove/{id}")
    public ResponseEntity<Void> deleteUserById(@PathVariable int id) {
        logger.info("Deleting user with ID: {}", id);
        userService.deleteUserById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("update/{id}")
    public ResponseEntity<Userdto> updateUser(@PathVariable int id, @Valid @RequestBody Userdto updatedUserDto) {
        logger.info("Updating user with ID: {}", id);
        Userdto updatedUser = userService.updateUser(id, updatedUserDto);
        logger.info("User updated successfully: {}", updatedUser.getUserName());
        return new ResponseEntity<>(updatedUser, HttpStatus.OK);
    }

    @GetMapping("/findbyusername/{userName}")
    public ResponseEntity<Userdto> findByUserName(@PathVariable String userName) {
        logger.info("Fetching user by username: {}", userName);
        Optional<Userdto> userDto = userService.findByUserName(userName);
        return userDto.map(user -> new ResponseEntity<>(user, HttpStatus.OK))
                .orElseThrow(() -> {
                    logger.warn("User not found with username: {}", userName);
                    return new UserNotFoundException("User not found with username: " + userName);
                });
    }

    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<String> handleUserNotFoundException(UserNotFoundException ex) {
        logger.error("Exception: {}", ex.getMessage());
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }
}
