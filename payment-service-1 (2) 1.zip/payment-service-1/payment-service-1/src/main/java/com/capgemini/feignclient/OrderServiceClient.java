package com.capgemini.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.capgemini.dto.OrderDTO;

@FeignClient(name = "order-service", url = "http://localhost:7273")  // URL to your OrderService
public interface OrderServiceClient {

	 @GetMapping("/orders/{orderId}")
	    OrderDTO getOrderById(@PathVariable("orderId") Long orderId);
}