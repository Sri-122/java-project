package com.capgemini.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

public class PaymentDTO {
    @NotNull(message = "{payment.amount.notnull}")
    @Positive(message = "{payment.amount.min}")
    private Double amount;

    @NotNull(message = "{payment.paymentMethod.notnull}")
    @Size(max = 50, message = "{payment.paymentMethod.size}")
    @Pattern(regexp = "^[a-zA-Z\\-\\s.,]+$", message = "{payment.paymentMethod.pattern}")
    private String paymentMethod;

   /*@NotNull(message = "{payment.paymentStatus.notnull}")
    private String paymentStatus;*/

    // No validation for paymentDate since it will be auto-generated
    private LocalDate paymentDate;

    /*@NotNull(message = "{payment.orderId.notNull}")*/
    private Long orderId;


    // Getters and Setters

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    /*public String getPaymentStatus() {

        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {

        this.paymentStatus = paymentStatus;
    }*/

    public LocalDate getPaymentDate() {

        return paymentDate;
    }

    /*public void setPaymentDate(LocalDate paymentDate) {
        this.paymentDate = LocalDate.now();
    }*/
    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    @Override
    public String toString() {
        return "PaymentDTO{" +
                "amount=" + amount +
                ", paymentMethod='" + paymentMethod + '\'' +
                //", paymentStatus='" + paymentStatus + '\'' +
                //", orderId=" + orderId +
                '}';
    }

}