package com.capgemini.model;

public enum PaymentStatus {
    SUCCESS,
    FAILURE
}
