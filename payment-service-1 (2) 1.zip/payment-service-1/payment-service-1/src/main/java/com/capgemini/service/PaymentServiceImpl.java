/*package com.capgemini.service;

import java.util.Date;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dto.OrderDTO;
import com.capgemini.dto.PaymentDTO;
import com.capgemini.exception.PaymentNotFoundException;
import com.capgemini.feignclient.OrderServiceClient;
import com.capgemini.model.Payment;
import com.capgemini.model.PaymentStatus;
import com.capgemini.repository.PaymentRepository;

import jakarta.validation.Valid;

@Service
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;
    private final OrderServiceClient orderServiceClient; // Inject Feign Client

    @Autowired
    public PaymentServiceImpl(PaymentRepository paymentRepository, OrderServiceClient orderServiceClient) {
        this.paymentRepository = paymentRepository;
        this.orderServiceClient = orderServiceClient;
    }

    // Create or Update Payment
    @Override
    public Payment saveOrUpdatePayment(@Valid PaymentDTO paymentDTO) {
        // Fetch order details from Order Service using Feign Client
        OrderDTO order = orderServiceClient.getOrderById(paymentDTO.getOrderId());  // Fetch the order using the orderId from PaymentDTO

        // Convert PaymentDTO to Payment Entity
        Payment payment = new Payment();
        payment.setAmount(paymentDTO.getAmount());
        payment.setPaymentMethod(paymentDTO.getPaymentMethod());

        // Determine Payment Status based on conditions
        PaymentStatus paymentStatus = determinePaymentStatus(paymentDTO.getAmount());
        payment.setPaymentStatus(paymentStatus);

        // Set the payment date automatically to the current date
        payment.setPaymentDate(new Date());

        // Set orderId from the response received from the Order Service
        payment.setOrderId(order.getOrderId());  // Assuming OrderDTO has a method getOrderId()

        // Save the Payment
        return paymentRepository.save(payment);
    }

    private PaymentStatus determinePaymentStatus(Double amount) {
        if (amount > 0) {
            return PaymentStatus.SUCCESS;
        } else if (amount < 0) {
            return PaymentStatus.FAILURE;
        }
        return PaymentStatus.FAILURE; // Default to FAILURE if amount is 0
    }

    // Get Payment by paymentId
    @Override
    public Payment getPaymentById(Long transactionId) {
        Optional<Payment> payment = paymentRepository.findById(transactionId);
        if (payment.isEmpty()) {
            throw new PaymentNotFoundException("Transaction with ID " + transactionId + " not found.");
        }
        return payment.get();
    }

    // Get Payments by Payment Status
    @Override
    public List<Payment> getPaymentsByStatus(PaymentStatus paymentStatus) {
        return paymentRepository.findByPaymentStatus(paymentStatus);
    }
}*/
package com.capgemini.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dto.OrderDTO;
import com.capgemini.dto.PaymentDTO;
import com.capgemini.exception.PaymentNotFoundException;
import com.capgemini.feignclient.OrderServiceClient;
import com.capgemini.model.Payment;
import com.capgemini.model.PaymentStatus;
import com.capgemini.repository.PaymentRepository;

import jakarta.validation.Valid;

@Service
public class PaymentServiceImpl implements PaymentService {

    private static final Logger logger = LoggerFactory.getLogger(PaymentServiceImpl.class);  // Logger initialization

    private final PaymentRepository paymentRepository;
    private final OrderServiceClient orderServiceClient; // Inject Feign Client

    @Autowired
    public PaymentServiceImpl(PaymentRepository paymentRepository, OrderServiceClient orderServiceClient) {
        this.paymentRepository = paymentRepository;
        this.orderServiceClient = orderServiceClient;
    }

    // Create or Update Payment
    @Override
    public Payment saveOrUpdatePayment(@Valid PaymentDTO paymentDTO) {
        logger.info("Received request to save or update payment for order ID: {}", paymentDTO.getOrderId());

        // Fetch order details from Order Service using Feign Client
        OrderDTO order = orderServiceClient.getOrderById(paymentDTO.getOrderId());  // Fetch the order using the orderId from PaymentDTO
        logger.debug("Fetched order details: {}", order);

        // Convert PaymentDTO to Payment Entity
        Payment payment = new Payment();
        payment.setAmount(paymentDTO.getAmount());
        payment.setPaymentMethod(paymentDTO.getPaymentMethod());

        // Determine Payment Status based on conditions
        PaymentStatus paymentStatus = determinePaymentStatus(paymentDTO.getAmount());
        payment.setPaymentStatus(paymentStatus);
        logger.debug("Determined payment status: {}", paymentStatus);

        // Set the payment date automatically to the current date
        payment.setPaymentDate(new Date());

        // Set orderId from the response received from the Order Service
        payment.setOrderId(order.getOrderId());  // Assuming OrderDTO has a method getOrderId()
        logger.debug("Set order ID in payment: {}", payment.getOrderId());

        // Save the Payment
        Payment savedPayment = paymentRepository.save(payment);
        logger.info("Payment saved successfully with transaction ID: {}", savedPayment.getTransactionId());

        return savedPayment;
    }

    private PaymentStatus determinePaymentStatus(Double amount) {
        if (amount > 0) {
            return PaymentStatus.SUCCESS;
        } else if (amount < 0) {
            return PaymentStatus.FAILURE;
        }
        return PaymentStatus.FAILURE; // Default to FAILURE if amount is 0
    }

    // Get Payment by paymentId
    @Override
    public Payment getPaymentById(Long transactionId) {
        logger.info("Received request to fetch payment with transaction ID: {}", transactionId);

        Optional<Payment> payment = paymentRepository.findById(transactionId);
        if (payment.isEmpty()) {
            logger.error("Payment with transaction ID {} not found.", transactionId);
            throw new PaymentNotFoundException("Transaction with ID " + transactionId + " not found.");
        }

        logger.info("Fetched payment: {}", payment.get());
        return payment.get();
    }

    // Get Payments by Payment Status
    @Override
    public List<Payment> getPaymentsByStatus(PaymentStatus paymentStatus) {
        logger.info("Fetching payments with status: {}", paymentStatus);

        List<Payment> payments = paymentRepository.findByPaymentStatus(paymentStatus);
        logger.debug("Fetched {} payments with status: {}", payments.size(), paymentStatus);

        return payments;
    }
}

