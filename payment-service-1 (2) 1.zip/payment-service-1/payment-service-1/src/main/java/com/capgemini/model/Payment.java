package com.capgemini.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.Date;

@Entity
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    private Double amount;

    private String paymentMethod;

    @Enumerated(EnumType.STRING)
    private PaymentStatus paymentStatus;

    private LocalDate paymentDate;
    private Long orderId;

    @PrePersist
    public void prePersist() {
        if (this.paymentDate == null) {
            this.paymentDate = LocalDate.now();  // Set the current date if it's not set
        }

        if (this.paymentStatus == null) {
            this.paymentStatus = PaymentStatus.SUCCESS;  // Set the default status as SUCCESS if not set
        }
    }

    // Getters and Setters
    public Long getTransactionId() {
        return transactionId;
    }

    public void setPaymentId(Long transactionId) {
        this.transactionId = transactionId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public PaymentStatus getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(PaymentStatus paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public LocalDate getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = LocalDate.now();
    }
    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }


    @Override
    public String toString() {
            return "Payment{" +
                    "transactionId=" + transactionId +
                    ", amount=" + amount +
                    ", paymentMethod='" + paymentMethod + '\'' +
                    ", paymentStatus=" + paymentStatus +
                    ", paymentDate=" + paymentDate +
                    ", orderId=" + orderId +
                    '}';
    }
}




