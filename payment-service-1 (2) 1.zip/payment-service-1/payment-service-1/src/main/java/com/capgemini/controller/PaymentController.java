/*package com.capgemini.controller;

import jakarta.validation.Valid;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.capgemini.dto.PaymentDTO;
import com.capgemini.exception.PaymentNotFoundException;
import com.capgemini.model.Payment;
import com.capgemini.model.PaymentStatus;
import com.capgemini.service.PaymentService;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentService paymentService;

    @Autowired
    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    // Create or Update a Payment
    @PostMapping("/create")
    public ResponseEntity<?> createOrUpdatePayment(@Valid @RequestBody PaymentDTO paymentDTO) {
        try {
            Payment savedPayment = paymentService.saveOrUpdatePayment(paymentDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedPayment);
        } catch (Exception e) {
            // Handle unexpected errors during payment creation/updating
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error while processing payment: " + e.getMessage());
        }
    }

    // Get Payment by paymentId
    @GetMapping("/{transactionId}")
    public ResponseEntity<?> getPaymentById(@PathVariable Long transactionId) {
        try {
            Payment payment = paymentService.getPaymentById(transactionId);
            return new ResponseEntity<>(payment, HttpStatus.OK);
        } catch (PaymentNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Payment with ID " + transactionId + " not found.");
        }
    }

    // Get Payments by Payment Status
    @GetMapping("/status/{status}")
    public ResponseEntity<?> getPaymentsByStatus(@PathVariable String status) {
        try {
            PaymentStatus paymentStatus = PaymentStatus.valueOf(status.toUpperCase());
            List<Payment> payments = paymentService.getPaymentsByStatus(paymentStatus);
            return new ResponseEntity<>(payments, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Invalid payment status: " + status);
        }
    }

}*/
package com.capgemini.controller;

import jakarta.validation.Valid;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.capgemini.dto.PaymentDTO;
import com.capgemini.exception.PaymentNotFoundException;
import com.capgemini.model.Payment;
import com.capgemini.model.PaymentStatus;
import com.capgemini.service.PaymentService;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private static final Logger logger = LoggerFactory.getLogger(PaymentController.class); // Logger initialization
    
    private final PaymentService paymentService;

    @Autowired
    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    // Create or Update a Payment
    @PostMapping("/create")
    public ResponseEntity<?> createOrUpdatePayment(@Valid @RequestBody PaymentDTO paymentDTO) {
        logger.info("Received request to create or update payment for order ID: {}", paymentDTO.getOrderId());
        
        try {
            Payment savedPayment = paymentService.saveOrUpdatePayment(paymentDTO);
            logger.info("Payment created/updated successfully with transaction ID: {}", savedPayment.getTransactionId());
            return ResponseEntity.status(HttpStatus.CREATED).body(savedPayment);
        } catch (Exception e) {
            // Log the error details
            logger.error("Error while processing payment: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error while processing payment: " + e.getMessage());
        }
    }

    // Get Payment by paymentId
    @GetMapping("/{transactionId}")
    public ResponseEntity<?> getPaymentById(@PathVariable Long transactionId) {
        logger.info("Received request to fetch payment with transaction ID: {}", transactionId);

        try {
            Payment payment = paymentService.getPaymentById(transactionId);
            logger.info("Fetched payment successfully: {}", payment);
            return new ResponseEntity<>(payment, HttpStatus.OK);
        } catch (PaymentNotFoundException e) {
            logger.error("Payment with ID {} not found.", transactionId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Payment with ID " + transactionId + " not found.");
        }
    }

    // Get Payments by Payment Status
    @GetMapping("/status/{status}")
    public ResponseEntity<?> getPaymentsByStatus(@PathVariable String status) {
        logger.info("Received request to fetch payments with status: {}", status);

        try {
            PaymentStatus paymentStatus = PaymentStatus.valueOf(status.toUpperCase());
            List<Payment> payments = paymentService.getPaymentsByStatus(paymentStatus);
            logger.info("Fetched {} payments with status: {}", payments.size(), paymentStatus);
            return new ResponseEntity<>(payments, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            logger.error("Invalid payment status: {}", status);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Invalid payment status: " + status);
        }
    }
}


