package com.capgemini.service;

import com.capgemini.dto.PaymentDTO;
import com.capgemini.model.Payment;
import com.capgemini.model.PaymentStatus;

import java.util.List;

public interface PaymentService {
    Payment saveOrUpdatePayment(PaymentDTO paymentDTO);
    Payment getPaymentById(Long transactionId);
    List<Payment> getPaymentsByStatus(PaymentStatus paymentStatus);
}
