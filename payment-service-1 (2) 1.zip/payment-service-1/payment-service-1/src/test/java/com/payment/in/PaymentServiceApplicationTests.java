package com.payment.in;

import com.capgemini.PaymentServiceApplication;
import com.capgemini.controller.PaymentController;
import com.capgemini.service.PaymentServiceImpl;
import com.capgemini.repository.PaymentRepository;
import com.capgemini.feignclient.OrderServiceClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(classes = PaymentServiceApplication.class) // Add the main application class explicitly
class PaymentServiceApplicationTests {

    private MockMvc mockMvc;

    @MockBean
    private PaymentServiceImpl paymentService;

    @MockBean
    private PaymentRepository paymentRepository;

    @MockBean
    private OrderServiceClient orderServiceClient;

    @Autowired
    private PaymentController paymentController;

    @BeforeEach
    public void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(paymentController).build();
    }

    @Test
    public void contextLoads() {
        // Test to make sure the application context loads successfully
    }

    @Test
    public void testCreatePayment() throws Exception {
        // Mocking the saveOrUpdatePayment method
        when(paymentService.saveOrUpdatePayment(any())).thenReturn(null);

        mockMvc.perform(post("/api/payments/create")
                        .contentType("application/json")
                        .content("{\"amount\": 100.0, \"paymentMethod\": \"Credit Card\", \"orderId\": 1}"))
                .andExpect(status().isCreated());
    }

    @Test
    public void testGetPaymentById() throws Exception {
        // Mocking the getPaymentById method
        when(paymentService.getPaymentById(1L)).thenReturn(null);

        mockMvc.perform(get("/api/payments/{transactionId}", 1L))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetPaymentsByStatus() throws Exception {
        // Mocking the getPaymentsByStatus method
        when(paymentService.getPaymentsByStatus(any())).thenReturn(null);

        mockMvc.perform(get("/api/payments/status/{status}", "SUCCESS"))
                .andExpect(status().isOk());
    }
}
