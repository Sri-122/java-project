package com.OnlineShopping.dto;
import java.util.List;
import java.util.Map;

import jakarta.persistence.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

public class CartDTO {

    private int cartId;
    private int userId;

//    @NotNull(message = "Products cannot be null")
//    @NotEmpty(message = "Products list cannot be empty")
//    private Map<Integer, Integer> products;
    @NotNull(message="{productCount.null}")
    @Positive(message="{productCount.negative}")
    private Integer productCount;

//    @NotNull(message = "{total.null}")
//    @Positive(message="{total.negative}")
    private Double total;

    @NotNull(message = "{productId.null}")
    private List<Long> productId;

    public CartDTO() {
        super();
    }

    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }



    public Integer getProductCount() {
        return productCount;
    }

    public void setProductCount(Integer productCount) {
        this.productCount = productCount;
    }

    public CartDTO(int cartId, Integer productCount, Double total, List<Long> productId) {
        this.cartId = cartId;

       this.productCount = productCount;
        this.total = total;
      this.productId = productId;
    }


//    public CartDTO(int cartId, int userId, Map<Integer, Integer> products, Double total) {
//        this.cartId = cartId;
//        this.userId = userId;
//        this.products = products;
//        this.total = total;
//    }


    public CartDTO(int cartId, int userId, Integer productCount, Double total, List<Long> productId) {
        this.cartId = cartId;
        this.userId = userId;
        this.productCount = productCount;
        this.total = total;
        this.productId = productId;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public List<Long> getProductId() {
        return productId;
    }

    public void setProductId(List<Long> productId) {
        this.productId = productId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

//    public Map<Integer, Integer> getProducts() {
//        return products;
//    }
//
//    public void setProducts(Map<Integer, Integer> products) {
//        this.products = products;
//    }
}
