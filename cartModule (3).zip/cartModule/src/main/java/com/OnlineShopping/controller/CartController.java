//package com.sweetmart.controller;
//import com.sweetmart.dto.CartDTO;
//import com.sweetmart.exceptions.CartNotFoundException;
//import com.sweetmart.model.Cart;
//import com.sweetmart.service.ICartService;
//import jakarta.validation.Valid;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.validation.annotation.Validated;
//import org.springframework.web.bind.annotation.*;
//import java.util.List;
//
//@RestController
//@RequestMapping("/cart")
//@Validated
//public class CartController {
//
//    @Autowired
//    private ICartService cartService;
//    @PostMapping("/addCart")
//    public ResponseEntity<CartDTO> addCart(@Valid @RequestBody CartDTO cart){
//        return new ResponseEntity<>(cartService.addCart(cart), HttpStatus.OK);
//    }
////
//    @PutMapping("/updateCart/{cartId}")
//        public ResponseEntity<CartDTO> updateCart(@Valid @RequestBody CartDTO cart, @PathVariable int cartId) throws CartNotFoundException {
//        cart.setCartId(cartId); // Set the cartId to the cartDTO object
//        return new ResponseEntity<>(cartService.updateCart(cart), HttpStatus.OK);
//}
//    //    @DeleteMapping ("/cancelCart/{cartId}")
////    public ResponseEntity<Cart> cancelCart(@Valid @RequestBody int cartId) throws CartNotFoundException{
////        return new ResponseEntity<>(cartService.cancelCart(cartId), HttpStatus.OK);
////    }
//    @DeleteMapping("/cancelCart/{cartId}")
//    public ResponseEntity<Cart> cancelCart(@Valid @PathVariable int cartId) throws CartNotFoundException {
//        Cart canceledCart = cartService.cancelCart(cartId);
//        return new ResponseEntity<>(canceledCart, HttpStatus.OK);
//    }
//    // Show all Carts (GET)
//    @GetMapping("/showAllCarts")
//    public ResponseEntity<List<Cart>> showAllCarts() {
//        return new ResponseEntity<>(cartService.showAllCarts(), HttpStatus.OK);
//    }
//
//    @GetMapping("/showAllCarts/{id}")
//    public ResponseEntity<Cart> showCartById(@PathVariable int id) {
//        try {
//            Cart cart = cartService.showCartById(id);
//            return new ResponseEntity<>(cart, HttpStatus.OK);
//        } catch (CartNotFoundException e) {
//            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//        }
//    }
//}


/*package com.OnlineShopping.controller;

import com.OnlineShopping.dto.CartDTO;
import com.OnlineShopping.exceptions.CartNotFoundException;
import com.OnlineShopping.model.Cart;
import com.OnlineShopping.service.ICartService;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/cart")
//@Validated
public class CartController {

    @Autowired
    private ICartService cartService;

    @PostMapping("/addCart")
    public ResponseEntity<CartDTO> addCart(@Valid @RequestBody CartDTO cartDTO) {
        CartDTO createdCart = cartService.addCart(cartDTO);
        createdCart.setCartId(cartDTO.getCartId());
        createdCart.setUserId(cartDTO.getUserId());
        return new ResponseEntity<>(createdCart, HttpStatus.CREATED);
    }

    @PutMapping("/updateCart/{cartId}")
    public ResponseEntity<CartDTO> updateCart(@RequestBody CartDTO cart, @PathVariable int cartId) throws CartNotFoundException {
        Cart existingCart = cartService.showCartById(cartId);
        if (existingCart == null) {
            throw new CartNotFoundException();
        }
        cart.setCartId(cartId);
        CartDTO updatedCart = cartService.updateCart(cart);
        return new ResponseEntity<>(updatedCart, HttpStatus.OK);
    }

    @DeleteMapping("/cancelCart/{cartId}")
    public ResponseEntity<String> cancelCart(@PathVariable int cartId) throws CartNotFoundException {
        String canceledCart = cartService.cancelCart(cartId);
        return new ResponseEntity<>(canceledCart, HttpStatus.OK);
    }

    @GetMapping("/showAllCarts")
    public ResponseEntity<List<Cart>> showAllCarts() {
        List<Cart> allCarts = cartService.showAllCarts();
        return new ResponseEntity<>(allCarts, HttpStatus.OK);
    }

    @GetMapping("/showAllCarts/{cartId}")
    public ResponseEntity<Cart> showCartById(@PathVariable int cartId) throws CartNotFoundException {
        Cart cart = cartService.showCartById(cartId);
        return new ResponseEntity<>(cart, HttpStatus.OK);
    }
//    @PostMapping("/calculateTotal")
//    public ResponseEntity<Double> calculateTotalCost(@RequestBody Map<Integer, Integer> productQuantities) {
//        ResponseEntity<Double> totalCost = calculateTotalCost(productQuantities);
//        return new ResponseEntity<>(total,HttpStatus.OK);
//    }

}*/





package com.OnlineShopping.controller;

import com.OnlineShopping.dto.CartDTO;
import com.OnlineShopping.exceptions.CartNotFoundException;
import com.OnlineShopping.model.Cart;
import com.OnlineShopping.service.ICartService;

import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cart")
//@Validated
public class CartController {

    private static final Logger logger = LoggerFactory.getLogger(CartController.class);

    @Autowired
    private ICartService cartService;

    @PostMapping("/addCart")
    public ResponseEntity<CartDTO> addCart(@Valid @RequestBody CartDTO cartDTO) {
        logger.info("Entering addCart() with cartDTO: {}", cartDTO);

        CartDTO createdCart = cartService.addCart(cartDTO);
        //createdCart.setCartId(cartDTO.getCartId());
        createdCart.setUserId(cartDTO.getUserId());

        logger.info("Cart created successfully with cartId: {}", createdCart.getCartId());
        return new ResponseEntity<>(createdCart, HttpStatus.CREATED);
    }

    @PutMapping("/updateCart/{cartId}")
    public ResponseEntity<CartDTO> updateCart(@RequestBody CartDTO cart, @PathVariable int cartId) throws CartNotFoundException {
        logger.info("Entering updateCart() with cartId: {}", cartId);

        Cart existingCart = cartService.showCartById(cartId);
        if (existingCart == null) {
            logger.error("Cart with cartId: {} not found", cartId);
            throw new CartNotFoundException();
        }

        cart.setCartId(cartId);
        CartDTO updatedCart = cartService.updateCart(cart);

        logger.info("Cart updated successfully with cartId: {}", updatedCart.getCartId());
        return new ResponseEntity<>(updatedCart, HttpStatus.OK);
    }

    @DeleteMapping("/cancelCart/{cartId}")
    public ResponseEntity<String> cancelCart(@PathVariable int cartId) throws CartNotFoundException {
        logger.info("Entering cancelCart() with cartId: {}", cartId);

        String canceledCart = cartService.cancelCart(cartId);
        logger.info("Cart with cartId: {} canceled successfully", cartId);

        return new ResponseEntity<>(canceledCart, HttpStatus.OK);
    }

    @GetMapping("/showAllCarts")
    public ResponseEntity<List<Cart>> showAllCarts() {
        logger.info("Entering showAllCarts()");

        List<Cart> allCarts = cartService.showAllCarts();
        logger.info("Found {} carts", allCarts.size());

        return new ResponseEntity<>(allCarts, HttpStatus.OK);
    }

    @GetMapping("/showAllCarts/{cartId}")
    public ResponseEntity<Cart> showCartById(@PathVariable int cartId) throws CartNotFoundException {
        logger.info("Entering showCartById() with cartId: {}", cartId);

        Cart cart = cartService.showCartById(cartId);
        logger.info("Found cart with cartId: {}", cartId);

        return new ResponseEntity<>(cart, HttpStatus.OK);
    }
}
