package com.OnlineShopping.service;
/*
import com.OnlineShopping.client.ProductServiceClient;
import com.OnlineShopping.dto.CartDTO;
import com.OnlineShopping.dto.Product;
import com.OnlineShopping.exceptions.CartNotFoundException;
import com.OnlineShopping.model.Cart;
import com.OnlineShopping.repo.ICartRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class CartServiceImpl implements ICartService {

    @Autowired
    private ICartRepository cartRepo;

    @Autowired
    private ProductServiceClient productServiceClient;

    @Override
    public CartDTO addCart(CartDTO cartDTO) {
        Cart cart = convertToEntity(cartDTO);
//        cart.setUserId(cartDTO.getUserId());
//        Cart new_cart = cartRepo.save(cart);
//        cart.setCartId(new_cart.getCartId());
//        cart.setUserId(new_cart.getUserId());
//        cart.setTotal(calculateTotalCost(cart.getProductId(), cart.getProductCount()));
//        Cart cart=convertToEntity(cartDTO);
//        Cart new_cart=cartRepo.save(cart);
//        new_cart.setUserId(cart.getUserId());

        cart.setTotal(calculateTotalCost(cart.getProductId(), cart.getProductCount()));
        cart.setUserId(cartDTO.getUserId());
        //cart.setCartId(cartDTO.getCartId());
        Cart savedCart=cartRepo.save(cart);
        //savedCart.setCartId(cartDTO.getCartId());
        return convertToDTO(savedCart);

    }

    @Override
    public CartDTO updateCart(CartDTO cartDTO) throws CartNotFoundException {
        int cartId = cartDTO.getCartId();
        Cart oldCart = cartRepo.findById(cartId).orElseThrow(() -> new CartNotFoundException("Cart not found with id: " + cartId));
        Cart updatedCart = convertToEntity(cartDTO);
        updatedCart.setUserId(cartDTO.getUserId());
        cartRepo.save(updatedCart);
        return convertToDTO(updatedCart);
    }
    @Override
    public String cancelCart(Integer cartId) throws CartNotFoundException {
        Cart cart = cartRepo.findById(cartId).orElseThrow(() -> new CartNotFoundException("Cart not found"));
        cartRepo.delete(cart);
        return "Cart deleted successfully";
    }

    @Override
    public List<Cart> showAllCarts() {
        return cartRepo.findAll();
    }


    @Override
    public Cart showCartById(Integer cartId) throws CartNotFoundException {
        Cart cart = cartRepo.findById(cartId).orElseThrow(() -> new CartNotFoundException("Cart not found"));
        return cart;
    }

//    @Override
//    public Double calculateTotalCost(List<Integer> productId, int productCount) {
//        return 0.0;
//    }
//
        public Double calculateTotalCost(List<Long> productId, int productCount) {
        double totalCost = 0;
        for (Long id : productId) {
            Product product = productServiceClient.getProductById(id);
            totalCost += product.getPrice() * productCount;
        }
        return totalCost;
    }
//    public Double calculateTotalCost(Map<Integer, Integer> productQuantities) {
//        double totalCost = 0;
//        for (Map.Entry<Integer, Integer> entry : productQuantities.entrySet()) {
//            Integer productId = entry.getKey();
//            Integer productCount = entry.getValue();
//
//            List<Product> products = productServiceClient.showAllProducts(productId);
//            if (!products.isEmpty()) {
//                totalCost += products.get(0).getPrice() * productCount;
//            } else {
//                System.out.println("No product found with ID: " + productId);
//            }
//        }
//        return totalCost;
//    }

    public CartDTO convertToDTO(Cart cart) {
        CartDTO cartDTO = new CartDTO();
        cartDTO.setCartId(cart.getCartId());
        cartDTO.setProductId(cart.getProductId());
        cartDTO.setTotal(cart.getTotal());
        cartDTO.setProductCount(cart.getProductCount());
        cartDTO.setUserId(cart.getUserId());
        return cartDTO;
    }

    public Cart convertToEntity(CartDTO cartDTO) {
        Cart cart = new Cart();
        cart.setCartId(cartDTO.getCartId());
        cart.setProductId(cartDTO.getProductId());
        cart.setProductCount(cartDTO.getProductCount());
        cart.setTotal(cartDTO.getTotal());
        return cart;
    }

}*/





import com.OnlineShopping.client.ProductServiceClient;
import com.OnlineShopping.dto.CartDTO;
import com.OnlineShopping.dto.Product;
import com.OnlineShopping.exceptions.CartNotFoundException;
import com.OnlineShopping.model.Cart;
import com.OnlineShopping.repo.ICartRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartServiceImpl implements ICartService {

    private static final Logger logger = LoggerFactory.getLogger(CartServiceImpl.class);

    @Autowired
    private ICartRepository cartRepo;

    @Autowired
    private ProductServiceClient productServiceClient;

    @Override
    public CartDTO addCart(CartDTO cartDTO) {
        logger.info("Entering addCart() with cartDTO: {}", cartDTO);

        Cart cart = convertToEntity(cartDTO);
        cart.setTotal(calculateTotalCost(cart.getProductId(), cart.getProductCount()));
        cart.setUserId(cartDTO.getUserId());
        
        logger.debug("Calculated total cost for cart: {}", cart.getTotal());

        Cart savedCart = cartRepo.save(cart);
        logger.info("Cart saved successfully with cartId: {}", savedCart.getCartId());

        return convertToDTO(savedCart);
    }

    @Override
    public CartDTO updateCart(CartDTO cartDTO) throws CartNotFoundException {
        logger.info("Entering updateCart() with cartDTO: {}", cartDTO);

        int cartId = cartDTO.getCartId();
        Cart oldCart = cartRepo.findById(cartId)
                .orElseThrow(() -> new CartNotFoundException("Cart not found with id: " + cartId));

        logger.debug("Found existing cart with cartId: {}", cartId);

        Cart updatedCart = convertToEntity(cartDTO);
        updatedCart.setTotal(calculateTotalCost(cartDTO.getProductId(), cartDTO.getProductCount()));
        updatedCart.setUserId(cartDTO.getUserId());

        cartRepo.save(updatedCart);
        logger.info("Cart updated successfully with cartId: {}", updatedCart.getCartId());

        return convertToDTO(updatedCart);
    }

    @Override
    public String cancelCart(Integer cartId) throws CartNotFoundException {
        logger.info("Entering cancelCart() with cartId: {}", cartId);

        Cart cart = cartRepo.findById(cartId)
                .orElseThrow(() -> new CartNotFoundException("Cart not found"));

        cartRepo.delete(cart);
        logger.info("Cart with cartId: {} deleted successfully", cartId);

        return "Cart deleted successfully";
    }

    @Override
    public List<Cart> showAllCarts() {
        logger.info("Entering showAllCarts()");
        List<Cart> carts = cartRepo.findAll();
        logger.debug("Found {} carts", carts.size());
        return carts;
    }

    @Override
    public Cart showCartById(Integer cartId) throws CartNotFoundException {
        logger.info("Entering showCartById() with cartId: {}", cartId);

        Cart cart = cartRepo.findById(cartId)
                .orElseThrow(() -> new CartNotFoundException("Cart not found"));
        logger.debug("Found cart with cartId: {}", cartId);

        return cart;
    }

    public Double calculateTotalCost(List<Long> productId, int productCount) {
        logger.info("Entering calculateTotalCost() with productIds: {} and productCount: {}", productId, productCount);

        double totalCost = 0;
        for (Long id : productId) {
            Product product = productServiceClient.getProductById(id);
            totalCost += product.getPrice() * productCount;
            logger.debug("Added cost for productId: {} price: {} * count: {} = {}", id, product.getPrice(), productCount, product.getPrice() * productCount);
        }

        logger.info("Calculated total cost: {}", totalCost);
        return totalCost;
    }

    public CartDTO convertToDTO(Cart cart) {
        logger.debug("Converting Cart to CartDTO with cartId: {}", cart.getCartId());
        CartDTO cartDTO = new CartDTO();
        cartDTO.setCartId(cart.getCartId());
        cartDTO.setProductId(cart.getProductId());
        cartDTO.setTotal(cart.getTotal());
        cartDTO.setProductCount(cart.getProductCount());
        cartDTO.setUserId(cart.getUserId());
        return cartDTO;
    }

    public Cart convertToEntity(CartDTO cartDTO) {
        logger.debug("Converting CartDTO to Cart with cartId: {}", cartDTO.getCartId());
        Cart cart = new Cart();
        cart.setCartId(cartDTO.getCartId());
        cart.setProductId(cartDTO.getProductId());
        cart.setProductCount(cartDTO.getProductCount());
        cart.setTotal(cartDTO.getTotal());
        return cart;
    }
}





